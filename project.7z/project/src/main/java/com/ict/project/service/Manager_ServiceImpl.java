package com.ict.project.service;

import org.springframework.stereotype.Service;

@Service
public class Manager_ServiceImpl implements Manager_Service{

}
