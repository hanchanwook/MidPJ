package com.ict.project.service;

public interface Personnel_Service {

}
