package com.ict.project.service;

public interface Manager_Service {

}
