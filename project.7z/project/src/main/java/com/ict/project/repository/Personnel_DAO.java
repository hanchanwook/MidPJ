package com.ict.project.repository;

import org.springframework.stereotype.Repository;

@Repository
public class Personnel_DAO {

}
