package com.ict.project.controller;

import org.springframework.stereotype.Controller;

@Controller
public class Personnel_Controller {

}
