package com.ict.project.repository;

import org.springframework.stereotype.Repository;

@Repository
public class Social_DAO {

}
