package com.ict.project.service;


public interface Nor_Service {
	
}
