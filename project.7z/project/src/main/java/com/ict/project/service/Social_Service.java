package com.ict.project.service;

public interface Social_Service {

}
