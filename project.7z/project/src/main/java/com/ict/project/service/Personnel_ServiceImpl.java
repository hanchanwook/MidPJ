package com.ict.project.service;

import org.springframework.stereotype.Service;

@Service
public class Personnel_ServiceImpl implements Personnel_Service{

}
